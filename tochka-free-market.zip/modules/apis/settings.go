package apis

import (
	"qxklmrhx7qkzais6.onion/Tochka/tochka-free-market/modules/settings"
)

var (
	APPLICATION_SETTINGS = settings.GetSettings()
)
