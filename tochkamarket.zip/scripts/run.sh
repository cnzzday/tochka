#!/usr/bin/env bash

./tochka-free-market run-server